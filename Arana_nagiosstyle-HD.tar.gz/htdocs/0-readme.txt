Arana Theme HD


1. DESCRIPTION

Arana Theme HD 1.1 is a skin for Nagios 3.X.
Original stylesheets and original icons have been modified to optimized for 1920x1200.

2. CREDITS

Arana Theme HD 1.1 is based on the Arana Theme Style v1.0 and modified by Cat03.
Arana Theme Style have been created by Eduardo L. Arana based on the theme by Yoann LAMY (Vautour Style). This Style
you can find here: 
http://exchange.nagios.org/directory/Addons/Frontends-%28GUIs-and-CLIs%29/Web-Interfaces/Themes-and-Skins/Vautour-Style/details
The menu of Arana Theme use the javascript framework MooTools (http://mootools.net/).
The icons of Arana Theme use "Silk icon set" (http://www.famfamfam.com/lab/icons/silk/) created by Mark James. 
"Silk icon set" is licensed under Creative Commons Attribution 2.5 License (http://creativecommons.org/licenses/by/2.5/).


3. INSTALL

Extract the tar.gz, rename it to "htdocs" and Replace the folder with 
(/usr/share/nagios/htdocs/ in Gentoo). Don't forget to copy your own icons to ~/logos